package com.example.bluejackpharmacy;

import android.os.Parcel;
import android.os.Parcelable;

public class News {
    String Header, Manufacturer, Price, Description;
    int ImageList;

    public String getHeader() {
        return Header;
    }

    public void setHeader(String header) {
        Header = header;
    }

    public String getManufacturer() {
        return Manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        Manufacturer = manufacturer;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public int getImageList() {
        return ImageList;
    }

    public void setImageList(int imageList) {
        ImageList = imageList;
    }

    public News(String header,int imageList, String manufacturer, String price, String description) {
        Header = header;
        Manufacturer = manufacturer;
        Price = price;
        Description = description;
        ImageList = imageList;
    }
}
