package com.example.bluejackpharmacy;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.preference.PreferenceActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HeaderViewListAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;

public class AdapterProduct extends RecyclerView.Adapter<AdapterProduct.ViewHolder>{

    Context context;
    ArrayList<News> newsArrayList;

    public AdapterProduct(Context context, ArrayList<News> newsArrayList) {
        this.context = context;
        this.newsArrayList = newsArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.list_item,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.ImageList.setImageResource(newsArrayList.get(position).getImageList());
        holder.Header.setText(newsArrayList.get(position).getHeader());
        holder.Manufacturer.setText(newsArrayList.get(position).getManufacturer());
        holder.Price.setText(newsArrayList.get(position).getPrice());

        holder.itemView.setOnClickListener(e-> {
                Intent intent = new Intent(holder.itemView.getContext(), Detail.class);
                intent.putExtra("Image", newsArrayList.get(position).ImageList);
                intent.putExtra("MedicineName", newsArrayList.get(position).Header);
                intent.putExtra("MedicineManufacturer", newsArrayList.get(position).Manufacturer);
                intent.putExtra("MedicinePrice", newsArrayList.get(position).Price);
                intent.putExtra("MedicineDescription", newsArrayList.get(position).Description);
                e.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return newsArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        ShapeableImageView ImageList;
        TextView Header, Price, Manufacturer;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ImageList = itemView.findViewById(R.id.ImageList);
            Header = itemView.findViewById(R.id.Header);
            Manufacturer = itemView.findViewById(R.id.Manufacturer);
            Price = itemView.findViewById(R.id.Price);
        }
    }
}
