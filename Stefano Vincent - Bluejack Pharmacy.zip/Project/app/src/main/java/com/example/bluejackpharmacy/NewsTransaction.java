package com.example.bluejackpharmacy;

import java.time.LocalDate;

public class NewsTransaction {
    String TransactionName, TransactionDate, TransactionPrice;
    int TransactionQuantity;

    public String getTransactionName() {
        return TransactionName;
    }

    public void setTransactionName(String transactionName) {
        TransactionName = transactionName;
    }

    public String getTransactionDate() {
        return TransactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        TransactionDate = transactionDate;
    }

    public String getTransactionPrice() {
        return TransactionPrice;
    }

    public void setTransactionPrice(String transactionPrice) {
        TransactionPrice = transactionPrice;
    }

    public int getTransactionQuantity() {
        return TransactionQuantity;
    }

    public void setTransactionQuantity(int transactionQuantity) {
        TransactionQuantity = transactionQuantity;
    }

    public NewsTransaction(String transactionName, String transactionDate, String transactionPrice, int transactionQuantity) {
        TransactionName = transactionName;
        TransactionDate = transactionDate;
        TransactionPrice = transactionPrice;
        TransactionQuantity = transactionQuantity;
    }
}
