package com.example.bluejackpharmacy;

import static com.example.bluejackpharmacy.RegisterPage.accounts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity implements View.OnClickListener {

    EditText Email, Password;
    Button LoginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        Email = findViewById(R.id.EmailUser);
        Password = findViewById(R.id.PassLogin);
        LoginBtn = findViewById(R.id.LoginBtn);
        LoginBtn.setOnClickListener(this);
        findViewById(R.id.RegisterBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(LoginPage.this, RegisterPage.class));
            }
        });
    }

    @Override
    public void onClick(View v) {
        String emailUser, passwordUser;
        emailUser = Email.getText().toString();
        passwordUser = Password.getText().toString();
        accounts.add(new dataUser("Stefano", "Stefano@gmail.com", "12345678", "A123"));

        for (int i=0; i<accounts.size(); i++){
            String EmailCheck, PassCheck;
            boolean EmailCorrect, PassCorrect;
            EmailCheck = (String) accounts.get(i).getEmail();
            PassCheck = (String) accounts.get(i).getPassword();
            EmailCorrect = EmailCheck.equals(emailUser);
            PassCorrect = PassCheck.equals(passwordUser);

            if (Email.getText().toString().isEmpty()){
                Toast.makeText(this,"Email must be filled",Toast.LENGTH_SHORT).show();
            }else if (Password.getText().toString().isEmpty()) {
                Toast.makeText(this,"Password must be filled",Toast.LENGTH_SHORT).show();
            }else if(EmailCorrect == true && PassCorrect == true){
                Intent intent = new Intent(this, HomePage.class);
                startActivity(intent);
            }else if(EmailCorrect == false && PassCorrect == true){
                Toast.makeText(this,"Email is incorrect",Toast.LENGTH_SHORT).show();
            }else if(EmailCorrect == true && PassCorrect == false){
                Toast.makeText(this,"Password is incorrect",Toast.LENGTH_SHORT).show();
            }
        }
    }
}