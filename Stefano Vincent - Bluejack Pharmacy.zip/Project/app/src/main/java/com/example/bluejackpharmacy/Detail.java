package com.example.bluejackpharmacy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.imageview.ShapeableImageView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Detail extends AppCompatActivity {

    ShapeableImageView imageDetail;
    TextView titleDetail, manufacturerDetail, priceDetail, descriptionDetail;
    TextView quantity;
    Button buyProduct;
    Integer image;
    String MedicineName, MedicineManufacturer, MedicinePrice, MedicineDescription;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        image = getIntent().getIntExtra("Image", 0);
        MedicineName = getIntent().getStringExtra("MedicineName");
        MedicineManufacturer = getIntent().getStringExtra("MedicineManufacturer");
        MedicinePrice = getIntent().getStringExtra("MedicinePrice");
        MedicineDescription = getIntent().getStringExtra("MedicineDescription");

        imageDetail = findViewById(R.id.ImageDetail);
        titleDetail = findViewById(R.id.TitleDetail);
        manufacturerDetail = findViewById(R.id.ManufacturerDetail);
        priceDetail = findViewById(R.id.PriceDetail);
        descriptionDetail = findViewById(R.id.Description);

        imageDetail.setImageResource(image);
        titleDetail.setText(MedicineName);
        manufacturerDetail.setText(MedicineManufacturer);
        priceDetail.setText(MedicinePrice);
        descriptionDetail.setText(MedicineDescription);

        quantity = findViewById(R.id.Quantity);
        buyProduct = findViewById(R.id.Buy);
        buyProduct.setOnClickListener(e->{
            if (quantity.getText().toString().isEmpty()){
                Toast.makeText(this, "Quantity must be filled", Toast.LENGTH_SHORT).show();
            } else if (Integer.valueOf(quantity.getText().toString()) <= 0) {
                Toast.makeText(this, "Quantity must be more than 1", Toast.LENGTH_SHORT).show();

            } else {
                DateFormat dateFormat = new SimpleDateFormat(" dd MM yyyy - HH:mm");
                Calendar calendar = Calendar.getInstance();
                HomePage.newsTransactions.add(new NewsTransaction(MedicineName, dateFormat.format(calendar.getTime()), MedicinePrice, Integer.parseInt(quantity.getText().toString())));
                Toast.makeText(this, "Transaction sucsessfully update!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, HomePage.class);
                intent.putExtra("Quantity", quantity.getText().toString());
                startActivity(intent);
            }
        });

        findViewById(R.id.BacktoHome).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(Detail.this, HomePage.class));
            }
        });
    }
}