package com.example.bluejackpharmacy;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    public static ArrayList<News> newsArrayList;
    private String[] newsHeader, manufacturer, prices, description;
    private int[] imageResourceID;
    private RecyclerView recycleview;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dataInitialize();
        recycleview = view.findViewById(R.id.RecycleViewHome);
        recycleview.setLayoutManager(new LinearLayoutManager(getContext()));
        recycleview.setHasFixedSize(true);
        AdapterProduct adapterProduct = new AdapterProduct(getContext(),newsArrayList);
        recycleview.setAdapter(adapterProduct);
        adapterProduct.notifyDataSetChanged();
    }

    public void dataInitialize() {
        newsArrayList = new ArrayList<>();
        newsHeader = new String[]{
                getString(R.string.Header1),
                getString(R.string.Header2),
        };

        imageResourceID = new int[]{
                R.drawable.image1,
                R.drawable.image2,
        };

        manufacturer = new String[]{
                getString(R.string.Manufacturer1),
                getString(R.string.Manufacturer2),
        };

        prices = new String[]{
                getString(R.string.Price1),
                getString(R.string.Price2),
        };

        description = new String[]{
                getString(R.string.Description1),
                getString(R.string.Description2),
        };

        for (int i=0; i<newsHeader.length;i++){
            News news = new News(newsHeader[i],imageResourceID[i],manufacturer[i],prices[i],description[i] );
            //News news = new News(newsHeader[i],imageResourceID[i],manufacturer[i],prices[i]);
            newsArrayList.add(news);
        }
    }
}