package com.example.bluejackpharmacy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterPage extends AppCompatActivity implements View.OnClickListener {

    public static boolean CekHuruf (String x){
        String regex = "^(?=.*[a-zA-Z])(?=.*[0-9])[A-Za-z0-9]+$";
        Pattern p = Pattern.compile(regex);
        if(x==null){
            return false;
        }
        Matcher m = p.matcher(x);
        return m.matches();
    }

    EditText User, Email, Phone, Pass, ConfirmPass;
    Button RegisterBtn;

    public static ArrayList<dataUser> accounts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        User = findViewById(R.id.UserRegister);
        Email = findViewById(R.id.EmailRegister);
        Phone = findViewById(R.id.PhoneRegister);
        Pass = findViewById(R.id.PassRegister);
        ConfirmPass = findViewById(R.id.ConfirmPassRegister);
        RegisterBtn = findViewById(R.id.RegisterBtnRegister);
        RegisterBtn.setOnClickListener(this);
        findViewById(R.id.LoginBtnRegister).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(RegisterPage.this, LoginPage.class));
            }
        });
    }

    @Override
    public void onClick(View v) {
        if(User.getText().toString().isEmpty()){
            Toast.makeText(this,"Username must be filled",Toast.LENGTH_SHORT).show();
        } else if(Email.getText().toString().isEmpty()){
            Toast.makeText(this,"Email must be filled",Toast.LENGTH_SHORT).show();
        } else if(Phone.getText().toString().isEmpty()){
            Toast.makeText(this,"Phone number must be filled",Toast.LENGTH_SHORT).show();
        } else if(Pass.getText().toString().isEmpty()){
            Toast.makeText(this,"Password must be filled",Toast.LENGTH_SHORT).show();
        } else if(!ConfirmPass.getText().toString().equals(Pass.getText().toString())){
            Toast.makeText(this,"Password didn't match",Toast.LENGTH_SHORT).show();
        } else if(User.getText().toString().length()<5){
            Toast.makeText(this,"Username must be more than 5",Toast.LENGTH_SHORT).show();
        } else if(!Email.getText().toString().endsWith(".com")){
            Toast.makeText(this,"Email must be end with \".com\"",Toast.LENGTH_SHORT).show();
        } else if(!CekHuruf(Pass.getText().toString())){
            Toast.makeText(RegisterPage.this,"Password must be Alphanumeric",Toast.LENGTH_SHORT).show();
        }else {
            String username = User.getText().toString();
            String emailUser = Email.getText().toString();
            String phoneUser = Phone.getText().toString();
            String passUser = Pass.getText().toString();
            accounts.add(new dataUser(username, emailUser, phoneUser, passUser));
            Intent intent = new Intent(this, LoginPage.class);
            startActivity(intent);
        }
    }
}