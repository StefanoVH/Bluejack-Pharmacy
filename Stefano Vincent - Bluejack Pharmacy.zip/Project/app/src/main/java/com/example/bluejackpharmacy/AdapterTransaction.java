package com.example.bluejackpharmacy;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class AdapterTransaction extends RecyclerView.Adapter<AdapterTransaction.ViewHolder> {

    ArrayList<NewsTransaction> newsTransactions;
    Context context;

    public AdapterTransaction(Context context, ArrayList<NewsTransaction> newsTransactions) {
        this.context = context;
        this.newsTransactions = newsTransactions;
    }

    @NonNull
    @Override
    public AdapterTransaction.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_transaction, parent, false);
       return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterTransaction.ViewHolder holder, int position) {
        holder.medicine.setText(newsTransactions.get(position).getTransactionName());
        holder.date.setText(newsTransactions.get(position).getTransactionDate());
        holder.price.setText(newsTransactions.get(position).getTransactionPrice());
        holder.quantity.setText(String.valueOf(newsTransactions.get(position).getTransactionQuantity()));

        holder.delete.setOnClickListener(e-> {
            newsTransactions.remove(newsTransactions.get(position));
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, getItemCount());
        });

        holder.update.setOnClickListener(v -> {
            int quantityChange = 0;
            try {
                quantityChange = Integer.parseInt(holder.quantityChange.getText().toString());
            } catch (Exception e) {}

            if(quantityChange == 0 ){
                Toast.makeText(context, "Input your new quantity!", Toast.LENGTH_SHORT).show();
            }
            else if(quantityChange>0){
                DateFormat dateFormat = new SimpleDateFormat("dd MM yyyy - HH:mm");
                Calendar calendar = Calendar.getInstance();
                newsTransactions.get(position).setTransactionQuantity(quantityChange);
                newsTransactions.get(position).setTransactionDate(dateFormat.format(calendar.getTime()));
                notifyItemChanged(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return newsTransactions.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView medicine, date, price, quantity, quantityChange;
        Button update, delete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            medicine = itemView.findViewById(R.id.HeaderTransaction);
            date = itemView.findViewById(R.id.DateTransaction);
            price = itemView.findViewById(R.id.PriceTransaction);
            quantity = itemView.findViewById(R.id.QuantityTransaction);
            quantityChange = itemView.findViewById(R.id.QuantityChange);

            update = itemView.findViewById(R.id.Update);
            delete = itemView.findViewById(R.id.Delete);
        }
    }
}
